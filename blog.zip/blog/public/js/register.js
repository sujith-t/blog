/**
 * @author Sujith T
 * 
 * <!In God We Trust>
 */
$(document).ready(function() {
    
    $("#signup").validate({
        rules: {
            fullname: {
                required: true,
                minlength: 3,
                maxlength: 200
            },
            email: {
                required: true,
                emailformat: true,
            },
            password: {
                required: true,
                minlength: 8,
                maxlength: 25
            },
            repassword: {
                required: true,
                minlength: 8,
                maxlength: 25,
                confirmpass: true
            }
        }
    });
    
    //check for confirm password
    $.validator.addMethod("confirmpass", function(value, element) {
        if(value === "") {
            return true;
        }
        
        if(value === $("#password").val()) {
            return true;
        }
        
        return false;
    }, "Re-ented password is incorrect");    
});