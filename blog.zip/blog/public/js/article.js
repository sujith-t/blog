/**
 * @author Sujith T
 * 
 * <!In God We Trust>
 */
$(document).ready(function() {
    
    $("#frmarticle").validate({
        ignore: [],
        debug: false,
        rules: {
            title: {
                required: true,
                minlength: 3,
                maxlength: 150
            },
            content: {
                minlength: 5,
                maxlength: 50000
            }
        }
    });
});