<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application;

use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;
use Zend\ServiceManager\Factory\InvokableFactory;

return [
    'router' => [
        'routes' => [
            'home' => [
                'type' => Literal::class,
                'options' => [
                    'route'    => '/',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
            'application' => [
                'type'    => Segment::class,
                'options' => [
                    'route'    => '/application[/:action]',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
            'user' => [
               'type' => Segment::class,
               'options' => [
                  'route' => '/user[/:action]',
                  'defaults' => [
                     'controller' => Controller\UserController::class,
                     'action' => 'login'
                  ],
                  'constraints' => [
                     'controller' => '[a-zA-Z]*',
                     'action' => '[a-zA-Z]*'
                  ]
               ]
            ],
            
            'blog' => [
               'type' => Segment::class,
               'options' => [
                  'route' => '/blog[/:action]',
                  'defaults' => [
                     'controller' => Controller\BlogController::class,
                     'action' => 'index'
                  ],
                  'constraints' => [
                     'controller' => '[a-zA-Z]*',
                     'action' => '[a-zA-Z]*'
                  ]
               ]
            ],
            
            'article' => [
               'type' => Segment::class,
               'options' => [
                  'route' => '/article[/:action]',
                  'defaults' => [
                     'controller' => Controller\ArticleController::class,
                     'action' => 'index'
                  ],
                  'constraints' => [
                     'controller' => '[a-zA-Z]*',
                     'action' => '[a-zA-Z]*'
                  ]
               ]
            ],            
        ],
    ],
    'controllers' => [
        'factories' => [
            Controller\IndexController::class => InvokableFactory::class,
        ],
        'invokables' => [
           'Application\Controller\User' => 'Application\Controller\UserController',
           'Application\Controller\Blog' => 'Application\Controller\BlogController', 
           'Application\Controller\Article' => 'Application\Controller\ArticleController', 
        ],        
    ],
    'view_manager' => [
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => [
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'application/index/index' => __DIR__ . '/../view/application/index/index.phtml',
            'application/user/login' => __DIR__ . '/../view/application/user/login.phtml',
            'application/user/register' => __DIR__ . '/../view/application/user/register.phtml',
            'application/blog/index' => __DIR__ . '/../view/application/blog/index.phtml',
            'application/blog/create' => __DIR__ . '/../view/application/blog/blogform.phtml',
            'application/blog/edit' => __DIR__ . '/../view/application/blog/blogform.phtml',
            'application/article/create' => __DIR__ . '/../view/application/article/blogpostform.phtml',
            'application/article/edit' => __DIR__ . '/../view/application/article/blogpostform.phtml',
            'application/article/view' => __DIR__ . '/../view/application/article/view.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
            'application/article/index' => __DIR__ . '/../view/application/article/index.phtml',
        ],
        'template_path_stack' => [
            __DIR__ . '/../view',
        ],
    ],
];
