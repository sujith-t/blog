<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Blog\Form\Article as articleForm;
use \Blog\Form\ArticleInputFilter;
use \Blog\Service\UserService as us;

use \Org\Db\DbAccess;

/**
 * Dealing with user accounts
 *
 * @author Sujith T
 */
class ArticleController extends AbstractActionController {

    /**
     * A page to display all articles of the blog
     *
     **/
    public function indexAction() {
        /*if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }*/
        
        $request = $this->getRequest();
        $id = $request->getQuery("blog_id");
        $q  = $request->getQuery("q");
        $blog = null;

        $blogDao = DbAccess::forModel("\Blog\Model\Blog");
        if(!is_null($id) && trim($id) != "") {
            $blog  = $blogDao->load($id);
        }

        if(!is_null($q) && trim($q) != "") {
            $blog  = $blogDao->load($q, "url_key");
        }
        
        //this is an invalid blog, sending back origin page
        if(is_null($blog)) {
            $route = (us::isUserLoggedIn()) ? "blog" : "home";
            return $this->redirect()->toRoute($route);
        }

        $articleDao = DbAccess::forModel("\Blog\Model\Article");
        
        $articles  = $articleDao->fetchAll(array("blog_id" => $blog->getId()), array(), array('created_at DESC'));
        $articles->buffer();
       
        $view   = ['articles' => $articles, 'blog' => $blog];
        
        return new ViewModel($view);
    }

    /**
     * Action to create
     * */
    public function createAction() {

        //if user not logged in send them to home page
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        
        $request = $this->getRequest();
        $blogId = $request->getQuery("blog_id");
        if(is_null($blogId) || trim($blogId) == "") {
            return $this->redirect()->toRoute('blog');
        }
        
        $blogDao = DbAccess::forModel("\Blog\Model\Blog");
        $blog = $blogDao->load($blogId);
        $loggedInUser = us::getLoggedInUser();
        
        //invalid blog or blog that doesn't belong to currently loggedin user
        if(is_null($blog) || $blog->getAuthorId() != $loggedInUser->getId()) {
             return $this->redirect()->toRoute('blog');
        }
        
        $form = new articleForm(['blog_id' => $blogId]);
        $view = array();

        if ($request->isPost()) {
            $data   = $request->getPost();
            $filter = new ArticleInputFilter();
            
            $form->setInputFilter($filter);
            $form->setData($data); 
            
            if ($form->isValid()) {
                $obj = $form->toObject();
                $obj->save();

                return $this->redirect()->toRoute('home', ["action" => "index"], ["query" => ["q" => $blog->getUrlKey()]]);
            }            
        }
        
        $view['form'] = $form;
        return new ViewModel($view);
    }

    /**
     * Action to edit
     * */
    public function editAction() {

        //if user not logged in send them to home page
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        $loggedInUser = us::getLoggedInUser();
        
        $request = $this->getRequest();
        $id = $request->getQuery("id");
        $articleDao = DbAccess::forModel("\Blog\Model\Article");
        $article = $articleDao->load($id);
        
        //invalid article
        if($id == null || $article == null) {
            return $this->redirect()->toRoute('blog');
        }        
        
        $blogDao = DbAccess::forModel("\Blog\Model\Blog");
        $blog = $blogDao->load($article->getBlogId());
        
        //if someone tries to edit which is not created by them we redirect to their dashboard page
        if($id == null || ($blog != null && $blog->getAuthorId() != $loggedInUser->getId())) {
            return $this->redirect()->toRoute('blog');
        }
        
        $form = new articleForm(['blog_id' => $id, 'article' => $article]);
        $view = array();

        if ($request->isPost()) {
            $data   = $request->getPost();
            $filter = new ArticleInputFilter();
            
            $form->setInputFilter($filter);
            $form->setData($data); 
            
            if ($form->isValid()) {
                $obj = $form->toObject();
                $obj->save();

                return $this->redirect()->toRoute('home', ["action" => "index"], ["query" => ["q" => $blog->getUrlKey()]]);
            }            
        }
        
        $view['form'] = $form;
        return new ViewModel($view);
    }
    
    /**
     * Action to View
     * */
    public function viewAction() {
        $request = $this->getRequest();
        $x  = $request->getQuery("x");
        $article = null;   
        
        $dao = DbAccess::forModel("\Blog\Model\Article");

        if(!is_null($x) && trim($x) != "") {
            $article  = $dao->load($x, "url_key");
        }
        
        //this is an invalid article, sending back origin page
        if(is_null($article)) {
            $route = (us::isUserLoggedIn()) ? "blog" : "home";
            return $this->redirect()->toRoute($route);
        }
        
        $view   = ['article' => $article];
        
        return new ViewModel($view);        
    } 
    
    /**
     * Action to Delete
     **/
    public function deleteAction() {
        //if user not logged in send them to home page
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        $loggedInUser = us::getLoggedInUser();
        
        $request = $this->getRequest();
        $id = $request->getQuery("id");
        $dao = DbAccess::forModel("\Blog\Model\Article");
        $article = $dao->load($id);
        
        $blog = $article->getBlog();
        
        //if someone tries to delete which they haven't created we redirect to their dashboard page
        if($id == null || ($article != null && $blog->getAuthorId() != $loggedInUser->getId())) {
            return $this->redirect()->toRoute('article', array('action' => 'index', 'blog_id' => $blog->getId()));
        }
        
        //now we do the business and redirect back to dashboard
        $article->delete();
        return $this->redirect()->toRoute('home', ["action" => "index"], ["query" => ["q" => $blog->getUrlKey()]]);
    }    
}
