<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Org\Db\DbAccess;

/**
 * Default controller
 *
 * @author Sujith T
 */
class IndexController extends AbstractActionController {

    const PAGE_SIZE = 30;
    
    public function indexAction() {

        $request = $this->getRequest();
        $blogUrl = $request->getQuery("q");
        $pageNumber = $request->getQuery("page");
        $dao    = DbAccess::forModel("\Blog\Model\Blog");
        
        //forward for blogs - search engine optimization
        if(!is_null($blogUrl) && trim($blogUrl) != "") {
            $blog = $dao->load($blogUrl, "url_key");    
            if(!is_null($blog) && $blog instanceof \Blog\Model\Blog) {
                return $this->forward()->dispatch('Application\Controller\ArticleController', ["action" => "index", "blog_id" => $blog->getId()]);
            }
        }
        
        //forward for article - search engine optimization
        $articleUrl = $request->getQuery("x");
        if(!is_null($articleUrl) && trim($articleUrl) != "") {
            $articleDao = DbAccess::forModel("\Blog\Model\Article");
            $article    = $articleDao->load($articleUrl, "url_key");
            
           if(!is_null($article) && $article instanceof \Blog\Model\Article) {
                return $this->forward()->dispatch('Application\Controller\ArticleController', ["action" => "view", "x" => $articleUrl]);
            }            
        }
        
        $totalRecords = $dao->count();
        $pages = ($totalRecords == 0) ? 1 : (floor($totalRecords/self::PAGE_SIZE) + 1);
        if(is_null($pageNumber) || trim($pageNumber) == "" || $pageNumber > $pages || $pageNumber < 1) {
            $pageNumber = 1;
        }
  
        $pagenation['size']     = self::PAGE_SIZE;
        $pagenation['start']    = ($pageNumber - 1) * self::PAGE_SIZE;
        
        $blogs  = $dao->fetchAll(array(), $pagenation, array('created_at DESC'));
        $blogs->buffer();
        
        $view   = ['blogs' => $blogs, 'pages' => $pages];
        
        return new ViewModel($view);
    }

}
