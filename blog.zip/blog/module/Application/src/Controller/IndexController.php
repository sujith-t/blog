<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Org\Db\DbAccess;

/**
 * Default controller
 *
 * @author Sujith T
 */
class IndexController extends AbstractActionController {

    public function indexAction() {

        $request = $this->getRequest();
        $q      = $request->getQuery("q");
        $dao    = DbAccess::forModel("\Blog\Model\Blog");
        
        //forward for blogs - search engine optimization
        if(!is_null($q) && trim($q) != "") {
            $blog = $dao->load($q, "url_key");
            
            if(!is_null($blog) && $blog instanceof \Blog\Model\Blog) {
                return $this->forward()->dispatch('Application\Controller\ArticleController', ["action" => "index", "blog_id" => $blog->getId()]);
            }
        }
        
        //forward for article - search engine optimization
        $x = $request->getQuery("x");
        if(!is_null($x) && trim($x) != "") {
            $articleDao = DbAccess::forModel("\Blog\Model\Article");
            $article    = $articleDao->load($x, "url_key");
            
           if(!is_null($article) && $article instanceof \Blog\Model\Article) {
                return $this->forward()->dispatch('Application\Controller\ArticleController', ["action" => "view", "x" => $x]);
            }            
        }
        
        $blogs  = $dao->fetchAll(array(), array(), array('created_at DESC'));
        $blogs->buffer();
        
        $view   = ['blogs' => $blogs];
        
        return new ViewModel($view);
    }

}
