<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Blog\Service\UserService as us;
use \Blog\Form\Signup;
use \Blog\Form\SignupInputFilter AS signupFilter;

/**
 * Dealing with user accounts
 *
 * @author Sujith T
 */
class UserController extends AbstractActionController {

    /**
     * this is the place where login post and validation happens
     *
     **/
    public function loginAction() {
        $request = $this->getRequest();
        $loginSucess = false;
        
        if ($request->isPost()) {
            $data = $request->getPost();
            
            $loginSucess = us::login($data['email'], $data['password']);
            if($loginSucess) {
                return $this->redirect()->toRoute('blog');
            } else {
                return $this->redirect()->toRoute('home');
            }
        }
        
        return new ViewModel();
    }

    /**
     * Register User
     *
     **/
    public function registerAction() {
        $request = $this->getRequest();
        $form = new Signup();
        $view = array();

        if ($request->isPost()) {
            $data = $request->getPost();
            $filter = new signupFilter();
            $form->setInputFilter($filter);

            $form->setData($data);

            if ($form->isValid()) {
                $obj = $form->toObject();
                $obj->save();
                
                us::login($data['email'], $data['password']);

                return $this->redirect()->toRoute('blog');
            }
        }

        $view['form'] = $form;
        return new ViewModel($view);
    }
    
    public function logoutAction() {
        us::logout();
        return $this->redirect()->toRoute('home');
    }    

}
