<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Blog\Form\Blog as blogForm;
use \Blog\Form\BlogInputFilter;
use \Blog\Service\UserService as us;

use \Org\Db\DbAccess;

/**
 * Dealing with user accounts
 *
 * @author Sujith T
 */
class BlogController extends AbstractActionController {

    /**
     * A Dashboard to display all user blogs
     *
     **/
    public function indexAction() {
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        
        $loggedInUser = us::getLoggedInUser();
        $dao = DbAccess::forModel("\Blog\Model\Blog");
        
        $blogs  = $dao->fetchAll(array("author" => $loggedInUser->getId()), array(), array('created_at DESC'));
        $blogs->buffer();
        
        $view   = ['blogs' => $blogs];
        
        return new ViewModel($view);
    }

    /**
     * Action to create
     * */
    public function createAction() {

        //if user not logged in send them to home page
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        
        $request = $this->getRequest();
        $form = new blogForm();
        $view = array();

        if ($request->isPost()) {
            $data   = $request->getPost();
            $filter = new BlogInputFilter();
            
            $form->setInputFilter($filter);
            $form->setData($data); 
            
            if ($form->isValid()) {
                $obj = $form->toObject();
                $loggedInUser = us::getLoggedInUser();
                
                $obj->setAuthorId($loggedInUser->getId());
                $obj->save();

                return $this->redirect()->toRoute('blog');
            }            
        }
        
        $view['form'] = $form;
        return new ViewModel($view);
    }

    /**
     * Action to edit
     * */
    public function editAction() {

        //if user not logged in send them to home page
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        $loggedInUser = us::getLoggedInUser();
        
        $request = $this->getRequest();
        $id = $request->getQuery("id");
        $dao = DbAccess::forModel("\Blog\Model\Blog");
        $blog = $dao->load($id);
        
        //if someone tries to edit which is not created by them we redirect to their dashboard page
        if($id == null || ($blog != null && $blog->getAuthorId() != $loggedInUser->getId())) {
            return $this->redirect()->toRoute('blog');
        }
        
        $form = new blogForm(['blog' => $blog]);
        $view = array();

        if ($request->isPost()) {
            $data   = $request->getPost();
            $filter = new BlogInputFilter();
            
            $form->setInputFilter($filter);
            $form->setData($data); 
            
            if ($form->isValid()) {
                $obj = $form->toObject();
                $obj->save();

                return $this->redirect()->toRoute('blog');
            }            
        }
        
        $view['form'] = $form;
        return new ViewModel($view);
    }
    
    /**
     * Action to Delete
     * */
    public function deleteAction() {
        //if user not logged in send them to home page
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        $loggedInUser = us::getLoggedInUser();
        
        $request = $this->getRequest();
        $id = $request->getQuery("id");
        $dao = DbAccess::forModel("\Blog\Model\Blog");
        $blog = $dao->load($id);
        
        //if someone tries to delete which is not created by them we redirect to their dashboard page
        if($id == null || ($blog != null && $blog->getAuthorId() != $loggedInUser->getId())) {
            return $this->redirect()->toRoute('blog');
        }
        
        //now we do the business and redirect back to dashboard
        $blog->delete();
        return $this->redirect()->toRoute('blog');
    }    
}
