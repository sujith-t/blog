-- MySQL dump 10.13  Distrib 8.0.12, for Linux (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `blog_id` int(11) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `inx_article_url_key` (`url_key`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `article_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'Spain paves way to remove Franco remains from mausoleum','Spain-paves-way-to-remove-Franco-remains-from-mausoleum-1536039029.0344','<p><strong>Spain&#39;s socialist government has passed a decree to exhume the remains of the late fascist dictator Francisco Franco from a huge mausoleum near Madrid.</strong></p>\r\n\r\n<p>The Valley of the Fallen, 50km (30 miles) from Madrid, was created by the dictator, who died in 1975.</p>\r\n\r\n<p>Today the site is seen as glorifying his victory in the 1936-39 Civil War.</p>\r\n\r\n<p>Gen Franco&#39;s family opposes the reburial plan. It is not clear where the remains will go, but the decree is expected to be approved by parliament.</p>\r\n\r\n<p>The Valley of the Fallen is also the resting place of about 37,000 dead from the civil war - soldiers from both sides.</p>\r\n\r\n<p>Far-right supporters of Franco pay homage to him at the site.</p>\r\n\r\n<p>Image copyright Reuters</p>\r\n\r\n<p>Image caption Franco&#39;s tomb is a pilgrimage site for Spanish fascists today</p>\r\n\r\n<p>But it is loathed by many in Spain as a monument to the triumph of fascism. Left-wing Republican prisoners were forced to help build it.</p>\r\n\r\n<h2>Read more on Franco&#39;s legacy:</h2>\r\n\r\n<ul>\r\n	<li><a href=\"https://www.bbc.com/news/world-europe-43344013\">Battle to strip Franco family of dictator&#39;s summer palace</a></li>\r\n	<li><a href=\"https://www.bbc.com/news/world-europe-43864116\">Spain exhumes bodies at Franco-era shrine</a></li>\r\n	<li><a href=\"https://www.bbc.com/news/world-europe-34844939\">Spain feels Franco&#39;s legacy 40 years after his death</a></li>\r\n</ul>\r\n\r\n<p>Spain&#39;s socialist government, in power since June, has made removing Franco&#39;s remains a priority. It sees their presence there as an affront to a mature democracy.</p>\r\n\r\n<p>If the Franco family does not specify where the remains are to go, the final resting place will be decided by the government.</p>\r\n\r\n<p>The Socialist Party has parliamentary support for the exhumation from the left-wing Podemos party and from Catalan and Basque nationalists.</p>\r\n\r\n<h2>Will the Valley of the Fallen remain a fascist symbol?</h2>\r\n\r\n<p>That is not what the government wants; the plan is to make it &quot;a place of commemoration, remembrance and homage to the victims of the war&quot;.</p>\r\n\r\n<p>But Deputy Prime Minister Carmen Calvo said the tomb of Primo de Rivera, founder of Franco&#39;s nationalist Falange movement, would remain undisturbed there. She described de Rivera as one of the civil war&#39;s victims. His tomb is opposite Franco&#39;s.</p>\r\n\r\n<p>De Rivera was shot by a Republican firing squad in 1936.</p>',1,'2018-09-04 00:00:29'),(2,'La Iglesia readmite a la profesora Resurrección Galera','La-Iglesia-readmite-a-la-profesora-Resurrección-Galera-1536039262.9104','<h2>17 a&ntilde;os despu&eacute;s, la docente vuelve a su empleo, que perdi&oacute; tras casarse con un hombre divorciado</h2>\r\n\r\n<p>17 a&ntilde;os despu&eacute;s, la profesora de religi&oacute;n <a href=\"https://ccaa.elpais.com/ccaa/2013/01/11/andalucia/1357933375_982707.html\">Resurrecci&oacute;n Galera</a> vuelve a su empleo. Galera, cuyo contrato no fue renovado en 2001 en un colegio p&uacute;blico por decisi&oacute;n del Obispado de Almer&iacute;a tras casarse con un divorciado, se reincorpor&oacute; este lunes al centro en cumplimiento de <a href=\"https://elpais.com/politica/2016/11/11/actualidad/1478874008_109737.html\">la sentencia dictada en 2016 por el Supremo</a>. El alto tribunal orden&oacute; su readmisi&oacute;n tras anular en su sentencia <a href=\"https://ccaa.elpais.com/ccaa/2012/12/17/andalucia/1355760817_491905.html\">un fallo previo de la justicia andaluza</a> y declarar su despido nulo &ldquo;por violaci&oacute;n de derechos fundamentes&rdquo;.</p>\r\n\r\n<p>Cuando fue despedida sin ning&uacute;n miramiento, en 2001, Resurrecci&oacute;n Galera ense&ntilde;aba religi&oacute;n cat&oacute;lica &mdash;desde hac&iacute;a siete a&ntilde;os&mdash; en el colegio p&uacute;blico Ferrer Guardia, de los Llanos de la Ca&ntilde;ada (Almer&iacute;a), y cobraba cada mes 234.000 pesetas (unos 1.400 euros), que le pagaba el Ministerio de Educaci&oacute;n. El contrato de esta profesora no fue renovado por decisi&oacute;n del Obispado de Almer&iacute;a tras contraer matrimonio civil con un divorciado, Johannes Romes, de nacionalidad alemana.</p>\r\n\r\n<p>A pesar de las sucesivas sentencias, no fue hasta el pasado mes de julio cuando el Ministerio de Educaci&oacute;n traslad&oacute; al Juzgado de lo Social 1 de Almer&iacute;a que Galera se incorporar&iacute;a este curso (2018-2019) en el citado centro docente del barrio almeriense.</p>',2,'2018-09-04 00:04:22'),(3,'UN treaty would protect high seas from over exploitation','UN-treaty-would-protect-high-seas-from-over-exploitation-1536039446.8295','<p><strong>The first significant steps towards legally protecting the high seas are to take place at the UN in New York.</strong></p>\r\n\r\n<p>These waters, which cover 46% of the planet&#39;s surface, are under threat from deep-sea mining, over-fishing and the patenting of marine genetic resources.</p>\r\n\r\n<p>Over the next two years, government representatives aim to hammer out a binding agreement to protect them against over-exploitation.</p>\r\n\r\n<p>But several nations, including the US, are lukewarm towards the proposals.</p>\r\n\r\n<p>Experts believe that the oceans of the world are vital for a number of reasons. Scientists say they capture around 90% of the extra heat and around 26% of the excess carbon dioxide created by humans through the burning of fossil fuels and other activities.</p>\r\n\r\n<ul>\r\n	<li><a href=\"https://www.bbc.com/news/science-environment-45400954\">Marvels of the deep and their superpowers</a></li>\r\n	<li><a href=\"https://www.bbc.com/news/science-environment-39347620\">Renewables&#39; deep-sea mining conundrum</a></li>\r\n	<li><a href=\"https://www.bbc.com/news/world-40248866\">Why are countries laying claim to the deep-sea floor?</a></li>\r\n</ul>\r\n\r\n<p>&quot;The half of our planet which is high seas is protecting terrestrial life from the worst impacts of climate change,&quot; said Prof Alex Rogers from Oxford University, UK, who has provided evidence to inform the UN treaty process getting under way on Tuesday.</p>\r\n\r\n<p>&quot;Yet we do too little to safeguard that or to protect the life within the ocean which is intrinsic to our collective survival. Protecting the biodiversity of the high seas by bringing good governance and law to the whole ocean is the single most important thing we can do to turn the tide for the blue heart of our planet.&quot;</p>\r\n\r\n<h2>So what exactly does &#39;high seas&#39; mean?</h2>\r\n\r\n<p>The high seas are defined as the oceans that lie beyond exclusive economic zones. These zones are usually within 370km (200 nautical miles) of a country&#39;s coastline. These waters cover one and a half times the total land area of the planet and are home to some of the rarest and most charismatic species - but all countries have the right to navigate, fly over, carry our scientific research and fish on the high seas without restriction.</p>\r\n\r\n<h2>Aren&#39;t these water already protected?</h2>\r\n\r\n<p>In 1982, the UN adopted the Convention of the Law of the Sea (UNCLOS) which, when it became active in 1994, regulated sea-bed mining and cable-laying to some extent. There are also a host of other international groups, including the International Whaling Commission that look after aspects of the seas, but there is no overarching treaty that would protect biodiversity or limit exploitation.</p>',3,'2018-09-04 00:07:26');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `blog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `about` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `url_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inx_blog_url_key` (`url_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (1,'Current International Affairs','This is a blog dedicated for current world affairs',1,NULL,'Current-International-Affairs-1536038896.5393'),(2,'La voz de Español en todo el mundo','Es un sitio que describe los asuntos mundiales actuales',1,NULL,'La-voz-de-Español-en-todo-el-mundo-1536039181.0207'),(3,'Science and Nature','New scientific discovery and the nature',1,NULL,'Science-and-Nature-1536039365.9004');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Sujith T','exodus123@gmail.com','12345678','2018-09-03 23:56:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-04 11:08:42
