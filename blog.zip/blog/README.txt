Please follow the instructions given below for installation

1. Download the zipfile and extract it. You will see [blog] folder with files.

2. create the blog database in MySQL prompt eg..
create database blog;

3. Restore blog database - Go to [blog] folder and you may find blog.sql. Please restore blog.sql with the blog database you created with following commands.
mysql -u root -p blog < blog.sql

4. move [blog] folder into the webroot (ie. Linux usually /var/www/html)

5. Specify the database connection in the configuration : Go to [blog] folder, open [blog]/config/config.xml. Please specify only the host, username, password fields. This would activate the database connection.
<?xml version="1.0" encoding="UTF-8"?>
<config>
    <database identity="default">
        <driver>Mysqli</driver>
        <host>localhost</host>
        <username>root</username>
        <password>mypassword</password>
        <dbname>blog</dbname>
    </database>
</config>

6. Start the webserver (ie. Linux usually - sudo service httpd start)
7. On your browser hit http://localhost/blog/public/index.php/ the browser would open a welcome page.

8. You may signup for an account or use the test account provided below
email : exodus123@gmail.com
password : 12345678
