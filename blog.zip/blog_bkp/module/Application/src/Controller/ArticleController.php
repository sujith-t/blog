<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Blog\Form\Blog as blogForm;
use \Blog\Form\BlogInputFilter;
use \Blog\Service\UserService as us;

use \Org\Db\DbAccess;

/**
 * Dealing with user accounts
 *
 * @author Sujith T
 */
class ArticleController extends AbstractActionController {

    /**
     * A page to display all articles of the blog
     *
     **/
    public function indexAction() {
        if(!us::isUserLoggedIn()) {
            return $this->redirect()->toRoute('home');
        }
        
        $loggedInUser = us::getLoggedInUser();
        $dao = DbAccess::forModel("\Blog\Model\Article");
        
        $blogs  = $dao->fetchAll(array("author" => $loggedInUser->getId()), array(), array('created_at DESC'));
        $blogs->buffer();
        
        $view   = ['blogs' => $blogs];
        
        return new ViewModel($view);
    }    
}
