<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use \Org\Db\DbAccess;

/**
 * Default controller
 *
 * @author Sujith T
 */
class IndexController extends AbstractActionController {

    public function indexAction() {

        $dao = DbAccess::forModel("\Blog\Model\Blog");
        
        $blogs  = $dao->fetchAll(array(), array(), array('created_at DESC'));
        $blogs->buffer();
        
        $view   = ['blogs' => $blogs];
        
        return new ViewModel($view);
    }

}
