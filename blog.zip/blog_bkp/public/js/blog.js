/**
 * @author Sujith T
 * 
 * <!In God We Trust>
 */
$(document).ready(function() {
    
    $("#frmblog").validate({
        rules: {
            blogname: {
                required: true,
                minlength: 3,
                maxlength: 100
            },
            about: {
                minlength: 5,
                maxlength: 250
            }
        }
    });
});